<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-900 dark:text-white leading-tight">
            <?php echo e(__('My Leads')); ?>

        </h2>
        <a href="<?php echo e(route('leads.import.form')); ?>" class="btn btn-info">Import Leads</a>
     <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-lg p-6">

            <?php if(session('success')): ?>
                <div class="mb-4 text-green-700 bg-green-100 border border-green-300 rounded-lg p-4 dark:bg-green-800 dark:text-green-100">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="overflow-x-auto">
                <table class="min-w-full table-auto border border-gray-300 dark:border-gray-700 text-sm">
                    <thead class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
                        <tr>
                            <th class="px-4 py-2 border">Name</th>
                            <th class="px-4 py-2 border">Job Title</th>
                            <th class="px-4 py-2 border">Company</th>
                            <th class="px-4 py-2 border">Location</th>
                            <th class="px-4 py-2 border">Email 1</th>
                            <th class="px-4 py-2 border">Email 2</th>
                            <th class="px-4 py-2 border">Phone</th>
                            <th class="px-4 py-2 border">LinkedIn URL</th>
                            <th class="px-4 py-2 border">Time</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-800 dark:text-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                <td class="px-4 py-2 border"><?php echo e($lead->name); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($lead->designation); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($lead->company); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($lead->location); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($lead->email1); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($lead->email2); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($lead->phone); ?></td>
                                <td class="px-4 py-2 border">
                                    <?php if($lead->url): ?>
                                        <a href="<?php echo e($lead->url); ?>" target="_blank" class="text-indigo-600 hover:underline">View</a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2 border"><?php echo e($lead->created_at->format('d M Y, H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center px-4 py-6 text-gray-500 dark:text-gray-300">
                                    No leads found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
<div class="mt-6">
    <?php echo e($leads->links()); ?>

</div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH I:\Leadify\Leadify\resources\views/leads/index.blade.php ENDPATH**/ ?>