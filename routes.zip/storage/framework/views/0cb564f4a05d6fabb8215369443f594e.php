<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 dark:text-white leading-tight">
            <?php echo e(__('Import Leads')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-lg p-6">
            <div class="max-w-3xl mx-auto mt-8 p-6 bg-white dark:bg-gray-800 shadow-lg rounded-xl">
                <?php if(session('success')): ?>
                <div class="mb-4 p-4 text-green-700 bg-green-100 rounded dark:bg-green-200 dark:text-green-900">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="mb-4 p-4 text-red-700 bg-red-100 rounded dark:bg-red-200 dark:text-red-900">
                    <?php echo e(session('error')); ?>

                </div>
                <?php if($errors->any()): ?>
                <ul class="list-disc list-inside text-sm text-red-600 dark:text-red-400">
                    <?php $__currentLoopData = session('errors')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('leads.import')); ?>" enctype="multipart/form-data" class="space-y-6">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label for="file" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Choose Excel/CSV File</label>
                        <input id="file" name="file" type="file" required
                            class="mt-1 block w-full text-sm text-gray-900 bg-gray-100 border border-gray-300 rounded-lg cursor-pointer dark:text-gray-300 dark:bg-gray-700 dark:border-gray-600">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Supported formats: .xls, .xlsx, .csv. Max size: 10MB.</p>
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <button type="submit"
                            class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition">
                            Import Leads
                        </button>
                    </div>
                </form>

                <div class="mt-8 text-sm text-gray-600 dark:text-gray-400">
                    <p><strong>⚠️ Important:</strong> Your file must contain headers like:</p>
                    <p><code class="bg-gray-100 dark:bg-gray-700 px-1 py-0.5 rounded">name, email1, email2, phone, url, designation, company, location</code></p>
                    <p class="mt-2">💡 Tip: Export some leads first to generate a template format.</p>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH I:\Leadify\Leadify\resources\views/leads/import.blade.php ENDPATH**/ ?>