<div>
    {{ $slot }}
</div>